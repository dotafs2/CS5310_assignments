# assignment 5


## environment
OS: macOS Sonoma 14.2.1  
CPU: arm64 chip
IDE: CLion  
C++: C++14    
C: C99  
QT6 required


## build
sry to use cmakelist not makefile, it is much easier to write.
cmakelist:

``
cmake
``

note: change the qt6 path to your own qt path
