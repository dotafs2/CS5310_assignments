# assignment 2

use a traveling day

## environment
OS: macOS Sonoma 14.2.1  
CPU: arm64 chip
IDE: CLion  
C++: C++14    
C: C99  
Extera librarys: ImageMagick

Bec I can not update other file such as ppm , so make sure the dictionary folder is exsit when compile.

I use camkelist to compile. Because makefile it so hard to compile both c and c++.

../ to store the master folder.