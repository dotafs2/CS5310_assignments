# assignment 1
notion: using one travel day

## TODO:
- [x] Do something interesting to an image
- [x] Implement green/blue screen compositing
- [x] Make your portfolio images
- [x] Scale function
- [x] Black and White issues
- [x] Blur the background


## environment
OS: macOS Sonoma 14.2.1  
CPU: arm64 chip