
## use cmake list to run

test both on windows and mac m1 

use cmakelist to make, test6a and 6b are two excuable files.

qt 6 required.