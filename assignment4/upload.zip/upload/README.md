# assignment 4

## output

<p align="center">
  <a href="https://github.com/dotafs2/CS5310_assignments"><img src="cmake-build-debug/1.gif" alt="Banner" width="700"></a>
</p>

<p align="center">
  <a href="https://github.com/dotafs2/CS5310_assignments"><img src="cmake-build-debug/2.gif" alt="Banner" width="700"></a>
</p>


## environment
OS: macOS Sonoma 14.2.1  
CPU: arm64 chip
IDE: CLion  
C++: C++14    
C: C99
QT6 required

makefile:
makefile is put into build dictionary.  
``
make
``

``
./assignment4``





cmakelist:

``
cmake
``
